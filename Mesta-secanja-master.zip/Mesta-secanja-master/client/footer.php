		<footer class="mbr-footer footer4 mbr-section" id="contacts4-3" data-rv-view="103" style="background-color: rgb(40, 50, 78); padding-top: 90px; padding-bottom: 10px; padding-top: 30px;">
			<div class="container">
				<div class="mbr-contacts row">

					<div class="col-sm-6">
						<div class="row">
							<div class="col-sm-6">
								<p class="mbr-contacts__text">
									<strong>Links</strong>
								</p>
								<ul class="mbr-contacts__list">
									<li>
										<a class="text-white" href="home.php">Home</a>
									</li>
									<li>
										<a class="text-white" href="regions.php">Regions</a>
									</li>
									<li>
										<a class="text-white" href="cemeteries.php">Cemeteries</a>
									</li>
									<li>
										<a class="text-white" href="about.php">About</a>
									</li>
								</ul>
							</div>
						</div>
					</div>

					<div class="col-sm-6">
						<form action="#" method="post">
							<div class="form-group">
								<label class="form-control-label" for="contacts4-3-email">Email<span class="form-asterisk">*</span></label>
								<input type="email" class="form-control input-sm input-inverse" name="email" required="" data-form-field="Email" id="contacts4-3-email">
							</div>

							<div class="form-group">
								<label class="form-control-label" for="contacts4-3-message">Message</label>
								<textarea class="form-control input-sm input-inverse" name="message" data-form-field="Message" rows="4" id="contacts4-3-message"></textarea>
							</div>

							<div class="mbr-buttons mbr-buttons--right btn-inverse">
								<button type="submit" class="btn btn-sm btn-black">
									Contact us
								</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</footer>
		
		<div id="scrollToTop" class="scrollToTop mbr-arrow-up">
			<a style="text-align: center;"><i class="mbr-arrow-up-icon" onclick="topFunction()"></i></a>
		</div>

		<script>
		function topFunction() {
			document.body.scrollTop = 0;
			document.documentElement.scrollTop = 0;
		}
		</script>
        <script type="text/javascript">
            var rootApp = angular.module('rootApp', niz);
            console.log(niz);
        </script>
		
	</body>
</html>
