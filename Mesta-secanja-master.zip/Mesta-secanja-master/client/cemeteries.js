var cemeteries = angular.module('cemeteries',[]);

cemeteries.controller('cemeteriesController', ['$scope', '$http', '$window', function ($scope, $http, $window) {

}]);