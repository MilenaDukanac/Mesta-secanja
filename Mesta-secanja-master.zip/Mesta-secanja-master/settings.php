<?php

$GLOBALS['settings'] = [
    "mysql_host" => "localhost",
    "mysql_user" => "root",
    "mysql_password" => "bigbang321",
    "mysql_db" => "centralcemeteries"
];
?>
